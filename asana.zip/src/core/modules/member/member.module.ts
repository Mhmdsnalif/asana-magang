import { Module } from '@nestjs/common';
import { memberProviders } from './member.providers';

@Module({
   
})
export class MemberModule {}
