export class ProjectDto{
    readonly idProject: string;
    readonly namaProject: string;
     deskripsi: string;
     dueDate: Date;
     status: Enumerator
}