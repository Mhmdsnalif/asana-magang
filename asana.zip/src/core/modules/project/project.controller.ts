import { Controller } from '@nestjs/common';

@Controller('project')
export class ProjectController {}
