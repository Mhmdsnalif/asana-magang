export const SEQUELIZE = 'SEQUELIZE';
export const DEVELOPMENT = 'development';
export const TEST = 'test';
export const PRODUCTION = 'production';
export const USER_REPOSITORY = 'USER_REPOSITORY';
export const PROJECT_REPOSITORY = 'PROJECT_REPOSITORY';
export const TEAM_REPOSITORY = 'TEAM_REPOSITORY';
export const MEMBER_REPOSITORY = 'MEMBER_REPOSITORY';
